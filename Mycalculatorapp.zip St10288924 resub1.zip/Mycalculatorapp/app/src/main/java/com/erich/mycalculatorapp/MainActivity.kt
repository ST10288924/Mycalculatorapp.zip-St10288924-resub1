package com.erich.mycalculatorapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    // Initialize references to UI components
    private lateinit var Num1editTextNumber: EditText
    private lateinit var Num2editTextNumber: EditText
    private lateinit var AnswerTextView: TextView
    private lateinit var buttonAdd: Button
    private lateinit var buttonSubtract: Button
    private lateinit var buttonMultiply: Button
    private lateinit var buttonDivide: Button
    private lateinit var clearbutton: Button
    private lateinit var squarerootbutton: Button
    private lateinit var powerbutton: Button

    @SuppressLint("SetTextI18n", "CutPasteId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize ui components
        Num1editTextNumber = findViewById(R.id.Num1editTextNumber)
        Num2editTextNumber = findViewById(R.id.Num2editTextNumber)
        AnswerTextView= findViewById(R.id.AnswerTextView)
        buttonAdd = findViewById(R.id.buttonAdd)
        buttonSubtract = findViewById(R.id.buttonSubtract)
        buttonMultiply = findViewById(R.id.buttonMultiply)
        buttonDivide = findViewById(R.id.buttonDivide)
        squarerootbutton = findViewById(R.id.squarerootbutton)
        powerbutton = findViewById(R.id.powerbutton)
        clearbutton = findViewById(R.id.clearbutton)

        // Set click listeners for operation buttons
        buttonAdd.setOnClickListener {
            val num1 = Num1editTextNumber.text.toString().toInt()
            val num2 = Num2editTextNumber.text.toString().toInt()
            addition(num1, num2)
        }

        buttonSubtract.setOnClickListener {
            val num1 = Num1editTextNumber.text.toString().toInt()
            val num2 = Num2editTextNumber.text.toString().toInt()
            subtraction(num1, num2)
        }

        buttonMultiply.setOnClickListener {
            val num1 = Num1editTextNumber.text.toString().toInt()
            val num2 = Num2editTextNumber.text.toString().toInt()
            multiplication(num1, num2)
        }

        buttonDivide.setOnClickListener {
            val num1 = Num1editTextNumber.text.toString().toInt()
            val num2 = Num2editTextNumber.text.toString().toInt()
            division(num1, num2)
        }

        squarerootbutton.setOnClickListener {
            val num1 = Num1editTextNumber.text.toString().toInt()
            squareRoot(num1)
        }

        powerbutton.setOnClickListener {
            val num1 = Num1editTextNumber.text.toString().toInt()
            val num2 = Num2editTextNumber.text.toString().toInt()
            val result = power(num1, num2)
            AnswerTextView.text = "$num1^$num2 = $result"
        }

        // Set click listener for clear button
        val clearButton = findViewById<Button>(R.id.clearbutton)
        clearButton.setOnClickListener {
            Num1editTextNumber.setText("")
            Num2editTextNumber.setText("")
            AnswerTextView.text = ""
            Toast.makeText(this, "Cleared", Toast.LENGTH_LONG).show()
        }
    }

    // Perform addition operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun addition(num1: Int, num2: Int) {
        val result = num1 + num2
        AnswerTextView.text = "Result: $num1 + $num2 = $result"
    }

    // Perform subtraction operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun subtraction(num1: Int, num2: Int) {
        val result = num1 - num2
        AnswerTextView.text = "Result: $num1 - $num2 = $result"
    }

    // Perform multiplication operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun multiplication(num1: Int, num2: Int) {
        val result = num1 * num2
        AnswerTextView.text = "Result: $num1 * $num2 = $result"
    }

    // Perform division operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun division(num1: Int, num2: Int) {
        val result = if (num2 != 0) num1.toDouble() / num2.toDouble() else Double.NaN
        AnswerTextView.text = if (!result.isNaN()) "Result: $num1 / $num2 = $result" else "Error: Division by 0 is not allowed"
    }

    // Perform square root operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun squareRoot(num1: Int) {
        val result: String = if (num1 >= 0) {
            val squareRoot = sqrt(num1.toDouble())
            "sqrt($num1) = $squareRoot"
        } else {
            val absNum = abs(num1)
            val imaginaryPart = sqrt(absNum.toDouble())
            "sqrt(-$absNum) = ${imaginaryPart}i"
        }

        result.also { AnswerTextView.text = it }
    }

    // Calculate the power of a number
    private fun power(base: Int, exponent: Int): Double {
        var result = 1.0
        for (i in 1..exponent) {
            result *= base
        }
        return result
    }
}



